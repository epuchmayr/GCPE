module.exports = {
  extends: [
      "@bcgov/wordpress-eslint/.eslint.js",
  ],
};