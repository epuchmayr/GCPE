<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'Sn Wp`[n$D&$:3h,$9{vg&AiTw5E@+.^)&CCnP8l*~S[mi)$#0qq!]n,9XjW/aZY' );
define( 'SECURE_AUTH_KEY',   'X<z70d|&daLJ;8VpjdlW f>SZv{| b5,ct!WA%=lwdVY3KTau|}El,oNpnE%Qxf`' );
define( 'LOGGED_IN_KEY',     'Q6.U6Jf`(&EZ79Eg4ng.8q+VoGGNOFf5v8~-2^ia9CLQ(lGAwW)7~zP.[<3Y1vB{' );
define( 'NONCE_KEY',         'K:x,%$3xnS)$+8RqZV)&uNvp:N+;i+pZ=7}iE: cdkU.Qb7OOK$etYSE}TCa`kH6' );
define( 'AUTH_SALT',         'pU_5%SdH[yei~^{>j2W60]Un|Qf!ziy@96*@?(wa$fW-`O9Hz~qZe6E!`d~oMufA' );
define( 'SECURE_AUTH_SALT',  '=O)ICU,R`HL%~/*{gefqH>>g:69<d:sxdh?/bA4[*v=^.Jv7<-AI1d*:G=ZW]Y5y' );
define( 'LOGGED_IN_SALT',    '@b{=y-;S&_p[5kMnJx4_jp{pK_fDeZ3Tt+6T])E::KD2)7XkT:= JWo0J=ghyEZ,' );
define( 'NONCE_SALT',        'RSc%)4K5Tc6}BuqwV>G/h$ ~nL1K @3YFhC-:KLC0s08guc;&4~+37B+x90c2I@i' );
define( 'WP_CACHE_KEY_SALT', 'NA8oJuO?65[n)G>m=)LT((RusyLw][k6h+2za]Nq!5;0|DN[E6}6x2ngOR4^Nf,@' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
